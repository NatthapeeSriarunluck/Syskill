for file in *; do 
    sed -n '10p' "$file";
    done